# Radzen Blazor components API reference

Search for a component by its name or part of the name e.g. `DataGrid`.
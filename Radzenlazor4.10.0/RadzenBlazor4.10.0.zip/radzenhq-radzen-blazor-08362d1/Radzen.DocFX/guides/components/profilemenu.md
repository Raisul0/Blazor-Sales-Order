# ProfileMenu component
This article demonstrates how to use the ProfileMenu component. 

```
<RadzenProfileMenu>
    <Template>
        <RadzenGravatar Email="user@example.com">
        </RadzenGravatar>
    </Template>
    <ChildContent>
        <RadzenProfileMenuItem Text="Buttons" Path="buttons" Icon="account_circle"></RadzenProfileMenuItem>
        <RadzenProfileMenuItem Text="Menu" Path="menu" Icon="line_weight"></RadzenProfileMenuItem>
        <RadzenProfileMenuItem Text="FileInput" Path="fileinput" Icon="attach_file"></RadzenProfileMenuItem>
        <RadzenProfileMenuItem Text="Dialog" Path="dialog" Icon="perm_media"></RadzenProfileMenuItem>
        <RadzenProfileMenuItem Text="Notification" Path="notification" Icon="announcement"></RadzenProfileMenuItem>
    </ChildContent>
</RadzenProfileMenu>
```